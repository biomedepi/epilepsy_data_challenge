from tensorflow import keras
import numpy as np
from utils import apply_preprocess_eeg


class SequentialGenerator(keras.utils.Sequence):

    def __init__(self, rec, batch_size=32, shuffle=False, verbose=True):
        
        'Initialization'
        self.batch_size = batch_size
        self.shuffle = shuffle

        frame = 2
        stride = 1
        fs = 250
        n_CH = 2

        rec_duration = len(rec.data[0])/rec.fs[0]
        n_segs = int(np.floor((np.floor(rec_duration) - frame)/stride))
        segments_start = np.arange(0, n_segs)*stride
        segments_stop = segments_start + frame

        self.data_segs = np.empty(shape=[len(segments_start), int(frame*fs), n_CH])
        self.verbose = verbose
        
        rec_data = apply_preprocess_eeg(rec)
        
        for s in range(len(segments_start)):
            
            start_seg = int(segments_start[s]*fs)
            stop_seg = int(segments_stop[s]*fs)

            if stop_seg > len(rec_data[0]):
                self.data_segs[s, :, 0] = np.zeros(fs*frame)
                self.data_segs[s, :, 1] = np.zeros(fs*frame)
            else:
                self.data_segs[s, :, 0] = rec_data[0][start_seg:stop_seg]
                self.data_segs[s, :, 1] = rec_data[1][start_seg:stop_seg]
        
        self.key_array = np.arange(len(self.data_segs))

        self.on_epoch_end()

    def __len__(self):
        return len(self.key_array) // self.batch_size

    def __getitem__(self, index):
        keys = np.arange(start=index * self.batch_size, stop=(index + 1) * self.batch_size)
        x = self.__data_generation__(keys)
        return x

    def on_epoch_end(self):
        if self.shuffle:
            self.key_array = np.random.permutation(self.key_array)

    def __data_generation__(self, keys):
        out = self.data_segs[self.key_array[keys], :, :]
        return out
